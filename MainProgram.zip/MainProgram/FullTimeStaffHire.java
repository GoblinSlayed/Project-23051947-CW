public class FullTimeStaffHire extends StaffHire { // New class FullTimeStaffHire that inherits attributes from the StaffHire class

    private double salary; // Variable salary with the double data type 
    private int weeklyFractionalHours; // Variable weeklyFractionalHours with the int data type

    // Constructor for the FullTimeStaffHire Class
    public FullTimeStaffHire(double salary, int weeklyFractionalHours, int vacancyNumber, String designationType, String jobType, String staffName, 
    String joiningDate, String qualification, String appointedBy, boolean joined){

        super(vacancyNumber, designationType, jobType, staffName, joiningDate, qualification, appointedBy, joined);
        this.salary = salary;
        this.weeklyFractionalHours = weeklyFractionalHours;
    }

    // Getters and Setters for the variables
    public double getSalary(){
        return salary;
    }

    public void setSalary(double newSalary ){
        this.salary = newSalary;
    }

    public int getWeeklyFractionalHours(){
        return weeklyFractionalHours;
    }

    public void setWeeklyFractionalHours(int newWeeklyFractionalHours){
        this.weeklyFractionalHours = newWeeklyFractionalHours;
    }

    // // Print method to display details
    @Override   
    public void printDetails() { 
        System.out.println("\nFull-Time Staff Details:");
        System.out.println("------------------------");
        System.out.println("Salary: £" + getSalary());
        System.out.println("Weekly Fractional Hours: " + getWeeklyFractionalHours());
        System.out.println("Vacancy Number: " + getVacancyNumber());
        System.out.println("Designation Type: " + getDesignationType());
        System.out.println("Job Type: " + getJobType());
        System.out.println("Staff Name: " + getStaffName());
        System.out.println("Joining Date: " + getJoiningDate());
        System.out.println("Qualification: " + getQualification());
        System.out.println("Appointed By: " + getAppointedBy());
        System.out.println("Joined: " + (isJoined() ? "Yes" : "No"));
        System.out.println("------------------------");
    }
}



