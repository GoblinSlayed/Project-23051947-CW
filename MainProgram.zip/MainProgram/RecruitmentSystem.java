import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

@SuppressWarnings({"unchecked", "rawtypes", "unused"}) // Suppress warnings for unchecked operations, raw types, and unused variables

public class RecruitmentSystem {
    private JFrame frame;
    private JTextField fullTimeVacancyField, fullTimeDesignationField, fullTimeJobTypeField, fullTimeStaffNameField,
            fullTimeJoiningDateField, fullTimeQualificationField, fullTimeAppointedByField, fullTimeSalaryField,
            fullTimeWeeklyHoursField, displayNumberField;
    private JTextField partTimeVacancyField, partTimeDesignationField, partTimeJobTypeField, partTimeStaffNameField,
            partTimeJoiningDateField, partTimeQualificationField, partTimeAppointedByField, partTimeWorkingHoursField,
            partTimeWagesPerHourField, partTimeShiftsField;
    private JCheckBox partTimeTerminatedCheckBox;
    private JButton addFullTimeButton, addPartTimeButton, displayButton, clearFullTimeButton, clearPartTimeButton,
            setSalaryButton, setShiftsButton, terminateButton;
    private ArrayList<StaffHire> staffList;
    private JCheckBox fullTimeJoinedCheckBox;

    public RecruitmentSystem() {
        staffList = new ArrayList<>();
        frame = new JFrame("Staff Recruitment System");
        frame.setSize(750, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel fullTimePanel = createFullTimePanel();
        JPanel partTimePanel = createPartTimePanel();

        tabbedPane.addTab("Full-Time Staff", fullTimePanel);
        tabbedPane.addTab("Part-Time Staff", partTimePanel);

        frame.add(tabbedPane);
        frame.setVisible(true);
    }

    private JPanel createFullTimePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        JPanel buttonPanel = new JPanel(new GridLayout(1, 5, 5, 5));

        addField(inputPanel, "Vacancy Number:", fullTimeVacancyField = new JTextField());
        addField(inputPanel, "Designation:", fullTimeDesignationField = new JTextField());
        addField(inputPanel, "Job Type:", fullTimeJobTypeField = new JTextField());
        addField(inputPanel, "Staff Name:", fullTimeStaffNameField = new JTextField());
        addField(inputPanel, "Joining Date:", fullTimeJoiningDateField = new JTextField());
        addField(inputPanel, "Qualification:", fullTimeQualificationField = new JTextField());
        addField(inputPanel, "Appointed By:", fullTimeAppointedByField = new JTextField());
        addField(inputPanel, "Salary:", fullTimeSalaryField = new JTextField());
        addField(inputPanel, "Weekly Hours:", fullTimeWeeklyHoursField = new JTextField());
        addField(inputPanel, "Display Number:", displayNumberField = new JTextField());
        fullTimeJoinedCheckBox = new JCheckBox("Joined");
        inputPanel.add(new JLabel("Joined:"));
        inputPanel.add(fullTimeJoinedCheckBox);

        addButton(buttonPanel, addFullTimeButton = new JButton("Add Full-Time Staff"), e -> addFullTimeStaff());
        addButton(buttonPanel, displayButton = new JButton("Display All Staff"), e -> displayAllStaff());
        addButton(buttonPanel, setSalaryButton = new JButton("Set Salary"), e -> setSalary());
        addButton(buttonPanel, terminateButton = new JButton("Terminate Staff"), e -> terminateStaff());
        addButton(buttonPanel, clearFullTimeButton = new JButton("Clear Fields"), e -> clearFullTimeFields());

        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createPartTimePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        JPanel buttonPanel = new JPanel(new GridLayout(1, 5, 5, 5));

        addField(inputPanel, "Vacancy Number:", partTimeVacancyField = new JTextField());
        addField(inputPanel, "Designation:", partTimeDesignationField = new JTextField());
        addField(inputPanel, "Job Type:", partTimeJobTypeField = new JTextField());
        addField(inputPanel, "Staff Name:", partTimeStaffNameField = new JTextField());
        addField(inputPanel, "Joining Date:", partTimeJoiningDateField = new JTextField());
        addField(inputPanel, "Qualification:", partTimeQualificationField = new JTextField());
        addField(inputPanel, "Appointed By:", partTimeAppointedByField = new JTextField());
        addField(inputPanel, "Working Hours:", partTimeWorkingHoursField = new JTextField());
        addField(inputPanel, "Wages Per Hour:", partTimeWagesPerHourField = new JTextField());
        addField(inputPanel, "Shifts:", partTimeShiftsField = new JTextField());
        partTimeTerminatedCheckBox = new JCheckBox("Terminated");
        inputPanel.add(new JLabel("Termination Status:"));
        inputPanel.add(partTimeTerminatedCheckBox);

        addButton(buttonPanel, addPartTimeButton = new JButton("Add Part-Time Staff"), e -> addPartTimeStaff());
        addButton(buttonPanel, displayButton = new JButton("Display All Staff"), e -> displayAllStaff());
        addButton(buttonPanel, setShiftsButton = new JButton("Set Shifts"), e -> setShifts());
        addButton(buttonPanel, terminateButton = new JButton("Terminate Staff"), e -> terminateStaff());
        addButton(buttonPanel, clearPartTimeButton = new JButton("Clear Fields"), e -> clearPartTimeFields());

        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void setSalary() {
        try {
            // Prompt the user for vacancy number and new salary
            String vacancyNumberInput = JOptionPane.showInputDialog(frame, "Enter Vacancy Number:", "Set Salary", JOptionPane.QUESTION_MESSAGE);
            String newSalaryInput = JOptionPane.showInputDialog(frame, "Enter New Salary:", "Set Salary", JOptionPane.QUESTION_MESSAGE);

            // Validate inputs
            if (vacancyNumberInput == null || newSalaryInput == null || vacancyNumberInput.isEmpty() || newSalaryInput.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Both fields are required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int vacancyNumber = Integer.parseInt(vacancyNumberInput);
            double newSalary = Double.parseDouble(newSalaryInput);

            // Search for the staff with the given vacancy number
            boolean found = false;
            for (StaffHire staff : staffList) {
                if (staff instanceof FullTimeStaffHire && staff.getVacancyNumber() == vacancyNumber) {
                    ((FullTimeStaffHire) staff).setSalary(newSalary); // Update the salary
                    JOptionPane.showMessageDialog(frame, "Salary updated successfully for Vacancy Number: " + vacancyNumber, "Success", JOptionPane.INFORMATION_MESSAGE);
                    found = true;
                    break;
                }
            }

            if (!found) {
                JOptionPane.showMessageDialog(frame, "Vacancy Number not found in Full-Time Staff.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setShifts() {
        try {
            // Prompt the user for vacancy number, staff name, and new shift
            String vacancyNumberInput = JOptionPane.showInputDialog(frame, "Enter Vacancy Number:", "Set Shifts", JOptionPane.QUESTION_MESSAGE);
            String staffNameInput = JOptionPane.showInputDialog(frame, "Enter Staff Name:", "Set Shifts", JOptionPane.QUESTION_MESSAGE);
            String newShiftInput = JOptionPane.showInputDialog(frame, "Enter New Shift:", "Set Shifts", JOptionPane.QUESTION_MESSAGE);

            // Validate inputs
            if (vacancyNumberInput == null || staffNameInput == null || newShiftInput == null ||
                vacancyNumberInput.isEmpty() || staffNameInput.isEmpty() || newShiftInput.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "All fields are required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int vacancyNumber = Integer.parseInt(vacancyNumberInput);

            // Search for the staff with the given vacancy number and staff name
            boolean found = false;
            for (StaffHire staff : staffList) {
                if (staff instanceof PartTimeStaffHire && staff.getVacancyNumber() == vacancyNumber &&
                    staff.getStaffName().equalsIgnoreCase(staffNameInput)) {
                    ((PartTimeStaffHire) staff).setShifts(newShiftInput); // Update the shift
                    JOptionPane.showMessageDialog(frame, "Shift updated successfully for Vacancy Number: " + vacancyNumber, "Success", JOptionPane.INFORMATION_MESSAGE);
                    found = true;
                    break;
                }
            }

            if (!found) {
                JOptionPane.showMessageDialog(frame, "No matching Part-Time Staff found with the given Vacancy Number and Staff Name.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid numbers for Vacancy Number.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void terminateStaff() {
        try {
            // Prompt the user for the vacancy number
            String vacancyNumberInput = JOptionPane.showInputDialog(frame, "Enter Vacancy Number to Terminate:", "Terminate Staff", JOptionPane.QUESTION_MESSAGE);

            // Validate input
            if (vacancyNumberInput == null || vacancyNumberInput.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Vacancy Number is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int vacancyNumber = Integer.parseInt(vacancyNumberInput);

            // Search for the staff with the given vacancy number
            boolean found = false;
            for (int i = 0; i < staffList.size(); i++) {
                if (staffList.get(i).getVacancyNumber() == vacancyNumber) {
                    staffList.remove(i); // Remove the staff from the list
                    JOptionPane.showMessageDialog(frame, "Staff with Vacancy Number " + vacancyNumber + " has been terminated.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    found = true;
                    break;
                }
            }

            if (!found) {
                JOptionPane.showMessageDialog(frame, "Vacancy Number not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid input. Please enter a valid number for Vacancy Number.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addField(JPanel panel, String label, JTextField field) {
        panel.add(new JLabel(label));
        panel.add(field);
    }

    private void addButton(JPanel panel, JButton button, ActionListener action) {
        button.addActionListener(action);
        panel.add(button);
    }

    private void addFullTimeStaff() {
        try {
            // Validate input fields
            if (fullTimeVacancyField.getText().isEmpty() || fullTimeDesignationField.getText().isEmpty() || fullTimeJobTypeField.getText().isEmpty() ||
                fullTimeStaffNameField.getText().isEmpty() || fullTimeJoiningDateField.getText().isEmpty() || fullTimeQualificationField.getText().isEmpty() ||
                fullTimeAppointedByField.getText().isEmpty() || fullTimeSalaryField.getText().isEmpty() || fullTimeWeeklyHoursField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Parse and create FullTimeStaffHire object
            int vacancyNumber = Integer.parseInt(fullTimeVacancyField.getText());
            String designation = fullTimeDesignationField.getText();
            String jobType = fullTimeJobTypeField.getText();
            String staffName = fullTimeStaffNameField.getText();
            String joiningDate = fullTimeJoiningDateField.getText();
            String qualification = fullTimeQualificationField.getText();
            String appointedBy = fullTimeAppointedByField.getText();
            double salary = Double.parseDouble(fullTimeSalaryField.getText());
            int weeklyHours = Integer.parseInt(fullTimeWeeklyHoursField.getText());
            boolean joined = fullTimeJoinedCheckBox.isSelected(); // Get the "Joined" status

            FullTimeStaffHire fullTimeStaff = new FullTimeStaffHire(salary, weeklyHours, vacancyNumber, designation, jobType, staffName, joiningDate, qualification, appointedBy, joined);
            staffList.add(fullTimeStaff); // Ensure the staff is added to the ArrayList
            JOptionPane.showMessageDialog(frame, "Full-Time Staff has been added successfully!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid input. Please check your entries.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addPartTimeStaff() {
        try {
            // Validate input fields
            if (partTimeVacancyField.getText().isEmpty() || partTimeDesignationField.getText().isEmpty() || partTimeJobTypeField.getText().isEmpty() ||
                partTimeStaffNameField.getText().isEmpty() || partTimeJoiningDateField.getText().isEmpty() || partTimeQualificationField.getText().isEmpty() ||
                partTimeAppointedByField.getText().isEmpty() || partTimeWorkingHoursField.getText().isEmpty() || partTimeWagesPerHourField.getText().isEmpty() ||
                partTimeShiftsField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Parse and create PartTimeStaffHire object
            int vacancyNumber = Integer.parseInt(partTimeVacancyField.getText());
            String designation = partTimeDesignationField.getText();
            String jobType = partTimeJobTypeField.getText();
            String staffName = partTimeStaffNameField.getText();
            String joiningDate = partTimeJoiningDateField.getText();
            String qualification = partTimeQualificationField.getText();
            String appointedBy = partTimeAppointedByField.getText();
            int workingHours = Integer.parseInt(partTimeWorkingHoursField.getText());
            double wagesPerHour = Double.parseDouble(partTimeWagesPerHourField.getText());
            String shifts = partTimeShiftsField.getText();
            boolean terminated = partTimeTerminatedCheckBox.isSelected();

            PartTimeStaffHire partTimeStaff = new PartTimeStaffHire(workingHours, wagesPerHour, shifts, terminated, vacancyNumber, designation, jobType, staffName, joiningDate, qualification, appointedBy, false);
            staffList.add(partTimeStaff); // Ensure the staff is added to the ArrayList
            JOptionPane.showMessageDialog(frame, "Part-Time Staff has been added successfully!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid input. Please check your entries.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void displayAllStaff() {
        if (staffList.isEmpty()) { // Checks if the ArrayList is empty
            JOptionPane.showMessageDialog(frame, "No staff added yet.", "Info", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Create a new JFrame to display staff details
            JFrame displayFrame = new JFrame("Staff List");
            displayFrame.setSize(600, 400);
            displayFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // Create a JTextArea to display staff details
            JTextArea staffDetailsArea = new JTextArea();
            staffDetailsArea.setEditable(false); // Make the text area read-only

            // Build staff details
            StringBuilder staffDetails = new StringBuilder();
            for (StaffHire staff : staffList) { // Iterates through the ArrayList
                staffDetails.append("------------------------\n");
                if (staff instanceof FullTimeStaffHire) {
                    FullTimeStaffHire fullTimeStaff = (FullTimeStaffHire) staff;
                    staffDetails.append("Salary: £").append(fullTimeStaff.getSalary()).append("\n");
                    staffDetails.append("Weekly Hours: ").append(fullTimeStaff.getWeeklyFractionalHours()).append("\n");
                } else if (staff instanceof PartTimeStaffHire) {
                    PartTimeStaffHire partTimeStaff = (PartTimeStaffHire) staff;
                    staffDetails.append("Working Hours: ").append(partTimeWorkingHoursField.getText()).append("\n");
                    staffDetails.append("Wages Per Hour: £").append(partTimeWagesPerHourField.getText()).append("\n");
                    staffDetails.append("Shifts: ").append(partTimeShiftsField.getText()).append("\n");
                    staffDetails.append("Termination Status: ").append(partTimeTerminatedCheckBox.isSelected() ? "Terminated" : "Active").append("\n");
                }
                staffDetails.append("Vacancy Number: ").append(staff.getVacancyNumber()).append("\n");
                staffDetails.append("Designation Type: ").append(staff.getDesignationType()).append("\n");
                staffDetails.append("Job Type: ").append(staff.getJobType()).append("\n");
                staffDetails.append("Staff Name: ").append(staff.getStaffName()).append("\n");
                staffDetails.append("Joining Date: ").append(staff.getJoiningDate()).append("\n");
                staffDetails.append("Qualification: ").append(staff.getQualification()).append("\n");
                staffDetails.append("Appointed By: ").append(staff.getAppointedBy()).append("\n");
                staffDetails.append("Joined: ").append(staff.isJoined() ? "Yes" : "No").append("\n");
                staffDetails.append("------------------------\n\n");
            }
            staffDetailsArea.setText(staffDetails.toString());

            // Add the text area to a scroll pane
            JScrollPane scrollPane = new JScrollPane(staffDetailsArea);

            // Add the scroll pane to the frame
            displayFrame.add(scrollPane);

            // Make the frame visible
            displayFrame.setVisible(true);
        }
    }

    private void clearFullTimeFields() {
        fullTimeVacancyField.setText("");
        fullTimeDesignationField.setText("");
        fullTimeJobTypeField.setText("");
        fullTimeStaffNameField.setText("");
        fullTimeJoiningDateField.setText("");
        fullTimeQualificationField.setText("");
        fullTimeAppointedByField.setText("");
        fullTimeSalaryField.setText("");
        fullTimeWeeklyHoursField.setText("");
    }

    private void clearPartTimeFields() {
        partTimeVacancyField.setText("");
        partTimeDesignationField.setText("");
        partTimeJobTypeField.setText("");
        partTimeStaffNameField.setText("");
        partTimeJoiningDateField.setText("");
        partTimeQualificationField.setText("");
        partTimeAppointedByField.setText("");
        partTimeWorkingHoursField.setText("");
        partTimeWagesPerHourField.setText("");
        partTimeShiftsField.setText("");
        partTimeTerminatedCheckBox.setSelected(false);
    }

    public static void main(String[] args) {
        new RecruitmentSystem();
    }
}












