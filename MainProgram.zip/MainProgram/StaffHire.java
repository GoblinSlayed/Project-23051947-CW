public class StaffHire {
    // Variables for the class StaffHire
    private int vacancyNumber;
    private String designationType;
    private String jobType;
    private String staffName;
    private String joiningDate;
    private String qualification;
    private String appointedBy;
    private boolean joined;

    // Constructor
    public StaffHire(int vacancyNumber, String designationType, String jobType, String staffName, 
                     String joiningDate, String qualification, String appointedBy, boolean joined) {
        this.vacancyNumber = vacancyNumber;
        this.designationType = designationType;
        this.jobType = jobType;
        this.staffName = staffName;
        this.joiningDate = joiningDate;
        this.qualification = qualification;
        this.appointedBy = appointedBy;
        this.joined = joined;
    }

    // Getters and Setters

    public int getVacancyNumber() {
        return vacancyNumber;
    }

    public void setVacancyNumber(int newVacancyNumber) {
        this.vacancyNumber = newVacancyNumber;
    }

    public String getDesignationType() {
        return designationType;
    }

    public void setDesignationType(String newDesignationType) {
        this.designationType = newDesignationType;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String newJobType) {
        this.jobType = newJobType;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String newStaffName) {
        this.staffName = newStaffName;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String newJoiningDate) {
        this.joiningDate = newJoiningDate;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String newQualification) {
        this.qualification = newQualification;
    }

    public String getAppointedBy() {
        return appointedBy;
    }

    public void setAppointedBy(String newAppointedBy) {
        this.appointedBy = newAppointedBy;
    }

    public boolean isJoined() {
        return joined;
    }

    public void setJoined(boolean newJoined) {
        this.joined = newJoined;
    }

    // Print method to display details
    public void printDetails() {
        System.out.println("------------------------");
        System.out.println("Vacancy Number: " + vacancyNumber);
        System.out.println("Designation Type: " + designationType);
        System.out.println("Job Type: " + jobType);
        System.out.println("Staff Name: " + staffName);
        System.out.println("Joining Date: " + joiningDate);
        System.out.println("Qualification: " + qualification);
        System.out.println("Appointed By: " + appointedBy);
        System.out.println("Joined: " + (joined ? "Yes" : "No"));
        System.out.println("------------------------");
    }
}
