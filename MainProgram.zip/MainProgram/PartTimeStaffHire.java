public class PartTimeStaffHire extends StaffHire {

    private int workingHour;
    private double wagesPerHour;
    private String shifts;
    private boolean terminated;

    public PartTimeStaffHire(int workingHour, double wagesPerhour, String shifts, boolean terminated, int vacancyNumber, String designationType, String jobType, String staffName, 
    String joiningDate, String qualification, String appointedBy, boolean joined){

        super(vacancyNumber, designationType, jobType, staffName, joiningDate, qualification, appointedBy, joined);
        
        this.workingHour = workingHour;
        this.wagesPerHour = wagesPerhour;
        this.shifts = shifts;
        this.terminated = false;
    }

    public int getWorkingHour(){
        return workingHour;
    }

    public void setWorkingHour(int newWorkingHour){
        workingHour = newWorkingHour;
    }

    public double getWagesPerHour(){
        return wagesPerHour;
    }

    public void setWagesPerHour(double newWagesPerHour){
        wagesPerHour = newWagesPerHour;
    }

    public String getShifts(){
        return shifts;
    }

    public void setShifts(String newShifts){
        shifts = newShifts;
    }

    public boolean getTerminated(){
        return terminated;
    }

    public void setTerminated(boolean newTerminated){
        terminated = newTerminated;
    }

    public void terminateStaff(boolean terminated){
        if(terminated == false){
            System.out.println("This member of staff has not been terminated");
        } else {
            System.out.println("This member of staff has now been terminated");
        }
    }

    @Override   
    public void printDetails() {
        System.out.println("\nPart-Time Staff Details:");
        System.out.println("------------------------");
        System.out.println("Working Hours: " + workingHour);
        System.out.println("Wages per Hour: £" + wagesPerHour);
        System.out.println("Shifts: " + shifts);
        System.out.println("Termination Status: " + (terminated ? "Terminated" : "Not Terminated"));
        System.out.println("Vacancy Number: " + getVacancyNumber());
        System.out.println("Designation Type: " + getDesignationType());
        System.out.println("Job Type: " + getJobType());
        System.out.println("Staff Name: " + getStaffName());
        System.out.println("Joining Date: " + getJoiningDate());
        System.out.println("Qualification: " + getQualification());
        System.out.println("Appointed By: " + getAppointedBy());
        System.out.println("Joined: " + (isJoined() ? "Yes" : "No"));
        System.out.println("------------------------");
    }
}

